from fastapi import FastAPI

app = FastAPI()

fake_recipes = [
    {
        "id": "101",
        "name": "High-Protein Burrito Bowl",
        "cuisine": "Mexican",
        "calories": 820,
        "protein": 52
    }
]

@app.get("/recipes")
def get_recipes(cuisine: str, minCalories: int, minProtein: int):
    results = [
        r for r in fake_recipes
        if r["cuisine"] == cuisine
        and r["calories"] >= minCalories
        and r["protein"] >= minProtein
    ]
    return {"results": results}
