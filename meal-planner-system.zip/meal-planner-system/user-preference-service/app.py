from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

users = {}

class Prefs(BaseModel):
    preferredCuisine: str
    minCalories: int
    minProtein: int

@app.post("/users")
def create_user(userId: str, prefs: Prefs):
    users[userId] = prefs.dict()
    return users[userId]

@app.get("/users/{userId}")
def get_user(userId: str):
    return users.get(userId, {"error": "User not found"})
