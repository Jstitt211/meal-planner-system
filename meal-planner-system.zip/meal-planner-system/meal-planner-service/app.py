from fastapi import FastAPI
from pydantic import BaseModel
import requests

app = FastAPI()

class PlanRequest(BaseModel):
    userId: str

@app.post("/plan")
def plan(req: PlanRequest):
    user = requests.get(f"http://localhost:8001/users/{req.userId}").json()

    recipes = requests.get(
        "http://localhost:8002/recipes",
        params={
            "cuisine": user["preferredCuisine"],
            "minCalories": user["minCalories"],
            "minProtein": user["minProtein"]
        }
    ).json()

    meal = recipes["results"][0] if recipes["results"] else None

    return {
        "userId": req.userId,
        "recommendedMeal": meal,
        "reason": "Matches your bulking goals"
    }
